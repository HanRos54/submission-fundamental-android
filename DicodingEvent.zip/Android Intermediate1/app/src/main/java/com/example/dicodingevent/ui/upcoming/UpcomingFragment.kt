package com.example.dicodingevent.ui.upcoming

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dicodingevent.R
import com.example.dicodingevent.adapter.EventAdapter
import com.example.dicodingevent.api.response.EventResponse
import com.example.dicodingevent.api.retrofit.ApiConfig
import com.example.dicodingevent.databinding.FragmentUpcomingBinding
import com.example.dicodingevent.ui.finished.FinishedFragment.Companion.TAG
import retrofit2.Call
import retrofit2.Response

class UpcomingFragment : Fragment() {
    private lateinit var upcomingFragmentBinding:FragmentUpcomingBinding;
    private lateinit var eventAdapter: EventAdapter;

    companion object{
        const val TAG = "UpcomingFragment"
    }

    @SuppressLint("FragmentLiveDataObserve")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?): View?
    {
        upcomingFragmentBinding = FragmentUpcomingBinding.inflate(inflater, container, false)
        val layoutManager = LinearLayoutManager(context)
        upcomingFragmentBinding.upcomingRecycle.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(context, layoutManager.orientation)
        upcomingFragmentBinding.upcomingRecycle.addItemDecoration(itemDecoration)

        val upcomingModel = ViewModelProvider(this,ViewModelProvider.NewInstanceFactory()).get(UpcomingViewModel::class.java)

        // ambil live data event
        upcomingModel.event.observe(viewLifecycleOwner) { events ->
            if (events != null) {
                upcomingFragmentBinding.progressBar.visibility = View.GONE
                eventAdapter = EventAdapter(events)
                upcomingFragmentBinding.upcomingRecycle.adapter = eventAdapter
                Log.i(TAG, "Data: $events")
            }
        }

        // ambil live data loading
        upcomingModel.loading.observe(this, Observer {
            upcomingFragmentBinding.progressBar.visibility = if (it) View.VISIBLE else View.GONE
        })

        // ambil live data fetch retrofit
        upcomingModel.fetchEvents()

        return upcomingFragmentBinding.root
    }

//    private fun fetchData() {
//        val client = ApiConfig.getApiService().getEvent(1)
//        client.enqueue(object : retrofit2.Callback<EventResponse> {
//            override fun onResponse(call: Call<EventResponse>, response: Response<EventResponse>) {
//                if (response.isSuccessful)
//                {
//                    upcomingFragmentBinding.progressBar.visibility = View.GONE
//
//                    eventAdapter = EventAdapter(response.body()!!.listEvents)
//                    upcomingFragmentBinding.upcomingRecycle.adapter = eventAdapter
//                    Log.i("Event API : " , "Data: ${response.body()}" )
//                }
//            }
//
//            override fun onFailure(call: Call<EventResponse>, t: Throwable) {
//                upcomingFragmentBinding.progressBar.visibility = View.VISIBLE
//                Log.e("API ERROR", "${t.message}")
//            }
//        })
//    }
}