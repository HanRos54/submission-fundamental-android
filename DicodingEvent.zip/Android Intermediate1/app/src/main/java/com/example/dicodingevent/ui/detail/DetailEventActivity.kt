package com.example.dicodingevent.ui.detail

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.ui.AppBarConfiguration
import com.bumptech.glide.Glide
import com.example.dicodingevent.api.response.Event
import com.example.dicodingevent.databinding.DetailEventBinding

class DetailEventActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: DetailEventBinding

    private lateinit var id:String
    private lateinit var linkUrl:String
    private lateinit var htmlDecription:String
    private lateinit var dataResponse:Event

    companion object{
        const val TAG:String = "DetailEventActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Get data from intent
        id = intent.getStringExtra("id").toString()

        binding = DetailEventBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        binding.decription.webViewClient = WebViewClient()

        //Hide actionBar
        val actionBar: ActionBar? = getSupportActionBar()
        actionBar?.hide()


        Log.i("id_event", id)

        // instance model
        val mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(DetailEventModel::class.java)

        mainViewModel.detailEvent.observe(this, Observer {
            if (it != null){
                linkUrl = it.link
                val htmlContent = """
                    <html>
                    <head>
                        <style>
                            body { font-family: Arial, sans-serif; }
                            h1 { color: blue; }
                            p { color: green; }
                            img { max-width: 100%; height: auto; }
                        </style>
                    </head>
                    <body>
                        ${it.description}
                    </body>
                    </html>
                """.trimIndent()

//                binding.decription.loadData(htmlContent, "text/html", "UTF-8")

                binding.decription.text = HtmlCompat.fromHtml(it.description, HtmlCompat.FROM_HTML_MODE_LEGACY)

                //Manipulate binding components
                Glide.with(binding.pictureEvent.context).load(it.imageLogo).into(binding.pictureEvent)
                binding.judulEvent.text = it.name
                binding.colaborator.text = it.ownerName
                binding.dateStart.text = it.beginTime
                binding.dateEnd.text = it.endTime
                binding.kuota.text = it.registrants.toString()
                binding.placement.text = it.cityName

                Log.i(TAG, "Data : ${it}")
            }
        })

        mainViewModel.isLoading.observe(this,Observer{
            showLoading(it)
        })

        // fetch event detail
        mainViewModel.fetchDetailEvent(id)

        binding.linkEvent.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(linkUrl)
            }
            startActivity(intent)
        }



    }

    override fun onSupportNavigateUp(): Boolean {
        onSupportNavigateUp()
        return true
    }

    private fun showLoading(isLoading:Boolean){
        binding.progressBar.visibility = if(isLoading) View.VISIBLE else View.GONE
    }
}