package com.example.dicodingevent.ui.upcoming

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.dicodingevent.api.response.EventResponse
import com.example.dicodingevent.api.response.ListEventsItem
import com.example.dicodingevent.api.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UpcomingViewModel : ViewModel() {

    companion object{
        const val TAG = "UpcomingViewModel"
    }

    private val _events = MutableLiveData<List<ListEventsItem>>()
    val event: LiveData<List<ListEventsItem>> = _events

    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _loading

    fun fetchEvents() {
        _loading.value = true
        val client = ApiConfig.getApiService().getEvent(1)

        client.enqueue(object : Callback<EventResponse> {
            override fun onResponse(call: Call<EventResponse>, response: Response<EventResponse>) {
                _loading.value = false
                if (response.isSuccessful) {
                    _events.value = response.body()?.listEvents
                }
            }

            override fun onFailure(call: Call<EventResponse>, t: Throwable) {
                _loading.value = false
                Log.i(TAG, "Error in : ${t.printStackTrace()}")
            }
        })
    }
}